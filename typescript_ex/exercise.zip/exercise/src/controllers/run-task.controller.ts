import { $ExpressRequest } from "../types";
import { Response } from 'express'
export function runTask(req: $ExpressRequest, res: Response) {
  return res.send({ payload: { exitCode: 0, result: "task done" } });
}
